-- Pipeline Demo's Lua script: proves mem.*, the sandbox, and a Lua-returned
-- list all work end to end. Not real game data — see sub-project 3 for that.

function update()
    -- Game code bytes live at ROM 0x080000AC (4 ASCII chars, e.g. "BPRE").
    -- Reading the first one with mem.u8 proves raw GBA bus reads work from Lua.
    local firstGameCodeByte = mem.u8(0x080000AC)

    local items = {}
    for i = 1, 3 do
        items[i] = { label = "Lua item " .. i, value = i * 7 }
    end

    return {
        romHeaderByte = firstGameCodeByte,
        items = items,
    }
end
